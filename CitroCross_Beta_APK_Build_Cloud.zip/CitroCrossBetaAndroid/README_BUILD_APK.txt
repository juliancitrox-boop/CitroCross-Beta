BUILD AUTOMATICO DE APK EN GITHUB ACTIONS

Este proyecto ahora incluye .github/workflows/build-apk.yml para compilar un APK Debug en GitHub Actions.

Pasos:
1. Crea un repositorio en GitHub.
2. Sube el contenido de esta carpeta (CitroCrossBetaAndroid) al repositorio.
3. En GitHub, abre Actions > Build CitroCross Beta APK.
4. Ejecuta Run workflow si no se inició por el push.
5. Espera a que termine exitosamente y abre la ejecución.
6. En Artifacts descarga CitroCross-Beta-APK. El archivo descargado contiene app-debug.apk.
7. En Android, abre el APK y permite instalar desde esa fuente si el sistema lo solicita.

Es un APK de prueba/debug, no firmado para distribución en Play Store.
PHP endpoints incluidos dentro de assets no se ejecutan en Android; PHP debe estar en hosting.
