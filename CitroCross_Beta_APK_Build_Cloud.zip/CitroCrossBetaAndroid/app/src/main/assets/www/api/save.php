<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['ok'=>false,'error'=>'method']); exit; }
$raw=file_get_contents('php://input'); if(strlen($raw)>2000000){http_response_code(413);echo json_encode(['ok'=>false]);exit;}
$body=json_decode($raw,true);
$player=$body['player']??''; $data=$body['data']??null;
if(!preg_match('/^[a-f0-9]{32}$/',$player) || !is_array($data)){http_response_code(400);echo json_encode(['ok'=>false,'error'=>'invalid']);exit;}
$dir=dirname(__DIR__).'/saves'; if(!is_dir($dir) && !mkdir($dir,0750,true)){http_response_code(500);echo json_encode(['ok'=>false]);exit;}
$file=$dir.'/'.$player.'.json'; $save=['updated'=>time(),'data'=>$data];
$tmp=$file.'.tmp'; if(file_put_contents($tmp,json_encode($save,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),LOCK_EX)===false || !rename($tmp,$file)){http_response_code(500);echo json_encode(['ok'=>false]);exit;}
echo json_encode(['ok'=>true]);
?>
