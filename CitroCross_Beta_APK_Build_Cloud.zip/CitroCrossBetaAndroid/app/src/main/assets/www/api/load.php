<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
$player=$_GET['player']??'';
if(!preg_match('/^[a-f0-9]{32}$/',$player)){http_response_code(400);echo json_encode(['ok'=>false]);exit;}
$file=dirname(__DIR__).'/saves/'.$player.'.json';
if(!is_file($file)){echo json_encode(['ok'=>true,'data'=>null]);exit;}
$save=json_decode(file_get_contents($file),true);
if(!is_array($save)){echo json_encode(['ok'=>true,'data'=>null]);exit;}
echo json_encode(['ok'=>true,'data'=>$save['data']??null]);
?>
