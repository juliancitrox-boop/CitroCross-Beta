CitroCross Beta - Proyecto Android WebView

Este ZIP contiene el proyecto fuente Android Studio, no un APK ya compilado.
Nombre de app: CitroCross Beta. Orientacion: horizontal. Pantalla completa.
HTML incluido: juego Beta existente y archivos PHP de autosave.

IMPORTANTE sobre PHP: Android no ejecuta PHP dentro de assets. Los endpoints api/save.php y api/load.php solo funcionan cuando se alojan en un servidor PHP. El HTML incluido mantiene guardado local via navegador; para sincronizacion remota hay que configurar el hosting PHP y ajustar el endpoint del juego a su URL.

Para compilar: abrir la carpeta en Android Studio, sincronizar Gradle, y Build > Build APK(s). Requiere Android SDK y Gradle, que no estaban disponibles en el entorno que genero este paquete.
